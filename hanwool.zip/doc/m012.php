<?
$cate_num = 1;
$cate_title = '회사소개';
$page_num = 2;
$page_title = '찾아오시는길';
include '../../../common.php';
include_once(G5_THEME_PATH.'/head.php');
?>






Lorem ipsum dolor sit amet. <?= $cate_num ?>







<?php
include_once(G5_THEME_PATH.'/tail.php');
?>