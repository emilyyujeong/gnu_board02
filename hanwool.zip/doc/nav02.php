<a href="<?= G5_THEME_URL ?>/doc/m021.php">제품소개</a>
<ul class="submenu">
    <li><a href="<?= G5_THEME_URL ?>/doc/m021.php">HWC540DL</a></li>
    <li><a href="<?= G5_THEME_URL ?>/doc/m022.php">HWC620FL</a></li>
    <li><a href="<?= G5_THEME_URL ?>/doc/m023.php">HWC680FL</a></li>
    <li><a href="<?= G5_THEME_URL ?>/doc/m024.php">HWC540FL</a></li>
    <li><a href="<?= G5_THEME_URL ?>/doc/m025.php">HWC790FL</a></li>
</ul>

